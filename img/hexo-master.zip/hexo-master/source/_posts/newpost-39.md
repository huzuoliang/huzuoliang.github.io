---
title: 随笔
date: 2022-04-05 23:35:11
tags: 随笔
index_img: /assets/headImg/note.png
---

百年之后，假设我的博客还在，未来的人读到上边的文字，是否会想到，写下这些文字的人，已经死了