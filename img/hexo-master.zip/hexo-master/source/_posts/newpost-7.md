---
title: mysql清空表，并让自增从0开始
date: 2020-12-23 13:51:34
tags: [编程,MySQL]
---

mysql清空表与自增

```mysql
truncate table table_name;
```

* tableName替换你的表名