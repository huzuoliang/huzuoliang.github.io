---
title: hexo-yilia主题相册
date: 2017-12-17 16:27:43
tags: [编程,前端]
---
### 起由
从yilia作者[Litten的博客](http://litten.me/)看到了他的相册，蛮喜欢的，就想给自己也弄一个，于是找了到他的博客在github上边的备份下载了source/photos文件夹，但是没有get到作者的方法，只好稍作修改把照片放到本地实现了作者博客中的效果。
<!--more-->
### 改动
1.由原作者图片托管在instagram改为托管在本地

2.由原作者图片尺寸固定改为尺寸可以写入ins.json

3.去掉原作者type选项，只可以放图片而不能放视频，并且图片格式只支持jpg（如果需要支持更多格式对ins.js稍作修改即可）

4.link作为图片名

5.去掉ins.jsn中的src选项

### 预览

点击左边的相册，或者[点此链接](/photos)

### 下载

请移步github下载：[https://github.com/dr34-m/yilia-photos](https://github.com/dr34-m/yilia-photos)

### 其他

略缩图可下载这个软件批量生成

链接: [https://pan.baidu.com/s/1slULnUd](https://pan.baidu.com/s/1slULnUd) 密码: 54je

推荐略缩图尺寸328x328