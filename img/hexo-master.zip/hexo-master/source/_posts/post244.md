---
title: Vs Code编写md文件实现实时预览
date: 2020-10-28 17:36:54
tags: 经验
---

使用组合键Ctrl + Shift + P，打开命令窗口，输入mark，点击即可在右边实时预览，如图

<!--more-->

![1.png](post244/1.png)